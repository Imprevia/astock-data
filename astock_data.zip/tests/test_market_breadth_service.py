from __future__ import annotations

import datetime as dt

import pytest

from astock_data.errors import DataSourceError, MarketValidationError
from astock_data.models import OHLCVBar, StockDataResult, Ticker
from astock_data.services.market_breadth import get_market_breadth

pytestmark = pytest.mark.unit


class EmptyTencent:
    def index_snapshots(self) -> dict[str, dict]:
        return {}


class EmptySina:
    def index_snapshots(self) -> dict[str, dict]:
        return {}

    def market_all(self, **kwargs) -> list[dict]:
        return []


def _stub_empty_tencent_sina(monkeypatch) -> None:
    """Mock Tencent/Sina to return empty so Eastmoney (last fallback) is exercised."""
    monkeypatch.setattr("astock_data.services.market_breadth.TencentClient", EmptyTencent)
    monkeypatch.setattr("astock_data.services.market_breadth.SinaClient", EmptySina)


class FakeEastmoney:
    def __init__(self, rows: list[dict]) -> None:
        self.rows = rows
        self.index_calls: list[str] = []

    def index_snapshot(self, secid: str) -> dict:
        self.index_calls.append(secid)
        names = {
            "1.000001": "上证指数",
            "0.399001": "深证成指",
            "0.399006": "创业板指",
            "1.000688": "科创50",
            "1.000300": "沪深300",
            "1.000905": "中证500",
        }
        return {"f58": names[secid], "f43": 1000.0, "f169": 1.0, "f170": 0.1}

    def clist_all(self, *, fields: str = "") -> list[dict]:
        self.fields = fields
        return self.rows


class FailingEastmoney(FakeEastmoney):
    def index_snapshot(self, secid: str) -> dict:
        raise DataSourceError("eastmoney down")

    def clist_all(self, *, fields: str = "") -> list[dict]:
        raise DataSourceError("eastmoney clist down")


def _bars(code: str, closes: list[float], start: str = "2026-06-15") -> StockDataResult:
    start_date = dt.date.fromisoformat(start)
    return StockDataResult(
        source="mock",
        retrieved_at=dt.datetime(2026, 6, 17, tzinfo=dt.UTC),
        ticker=Ticker(code=code, market="sh" if code.startswith("6") else "sz"),
        bars=[
            OHLCVBar(
                date=(start_date + dt.timedelta(days=index)).isoformat(),
                open=close,
                high=close,
                low=close,
                close=close,
                volume=1000,
            )
            for index, close in enumerate(closes)
        ],
    )


def test_market_breadth_counts_limits_and_returns_indices(monkeypatch) -> None:
    # 东财是最后降级源，需要让腾讯/新浪返回空才能触发东财。
    class EmptyTencent:
        def index_snapshots(self) -> dict[str, dict]:
            return {}
    class EmptySina:
        def index_snapshots(self) -> dict[str, dict]:
            return {}
        def market_all(self, **kwargs) -> list[dict]:
            return []
    monkeypatch.setattr("astock_data.services.market_breadth.TencentClient", EmptyTencent)
    monkeypatch.setattr("astock_data.services.market_breadth.SinaClient", EmptySina)

    eastmoney = FakeEastmoney(
        [
            {"f12": "000001", "f14": "平安银行", "f2": 10.98, "f3": 9.8},
            {"f12": "300001", "f14": "特锐德", "f2": 12.0, "f3": 19.6},
            {"f12": "688017", "f14": "绿的谐波", "f2": 8.0, "f3": -19.5},
            {"f12": "920001", "f14": "北证样本", "f2": 13.0, "f3": 29.6},
            {"f12": "600001", "f14": "*ST样本", "f2": 4.8, "f3": -4.8},
        ]
    )

    result = get_market_breadth("2026-06-17", eastmoney=eastmoney, stock_data_func=lambda *args: _bars(args[0], [10, 11, 12.1]))

    assert [item.key for item in result.indices] == ["sh", "sz", "cyb", "kc50", "hs300", "zz500"]
    assert eastmoney.index_calls == ["1.000001", "0.399001", "0.399006", "1.000688", "1.000300", "1.000905"]
    assert result.limit_stats.limit_up_count == 3
    assert result.limit_stats.limit_down_count == 2
    assert result.source == "eastmoney+derived"
    assert result.raw["sources"]["board_ladders"] == "derived.kline.threshold"


def test_eastmoney_failure_uses_tencent_indices_and_sina_rows(monkeypatch) -> None:
    class FakeTencent:
        def index_snapshots(self) -> dict[str, dict]:
            return {
                key: {"name": f"{key}指数", "price": 1000.0, "change": 1.0, "change_pct": 0.1}
                for key in ["sh", "sz", "cyb", "kc50", "hs300", "zz500"]
            }

    class FakeSina:
        def market_all(self) -> list[dict]:
            return [
                {"code": "000001", "name": "平安银行", "close": 10.98, "change_pct": 9.8},
                {"code": "688017", "name": "绿的谐波", "close": 8.0, "change_pct": -19.5},
            ]

        def index_snapshots(self) -> dict[str, dict]:
            raise AssertionError("Sina indices should not be used when Tencent succeeds")

    monkeypatch.setattr("astock_data.services.market_breadth.TencentClient", FakeTencent)
    monkeypatch.setattr("astock_data.services.market_breadth.SinaClient", FakeSina)

    result = get_market_breadth(
        "2026-06-17",
        eastmoney=FailingEastmoney([]),
        stock_data_func=lambda *args: _bars(args[0], [10, 11]),
    )

    assert result.raw["sources"]["indices"] == "tencent"
    assert result.raw["sources"]["limit_stats"] == "sina"
    assert result.limit_stats.limit_up_count == 1
    assert result.limit_stats.limit_down_count == 1


def test_tencent_failure_uses_sina_indices(monkeypatch) -> None:
    class FakeTencent:
        def index_snapshots(self) -> dict[str, dict]:
            raise DataSourceError("tencent down")

    class FakeSina:
        def index_snapshots(self) -> dict[str, dict]:
            return {
                key: {"name": f"{key}指数", "price": 1000.0, "change": 1.0, "change_pct": 0.1}
                for key in ["sh", "sz", "cyb", "kc50", "hs300", "zz500"]
            }

        def market_all(self) -> list[dict]:
            return [{"code": "000001", "name": "平安银行", "close": 10.0, "change_pct": 0.0}]

    monkeypatch.setattr("astock_data.services.market_breadth.TencentClient", FakeTencent)
    monkeypatch.setattr("astock_data.services.market_breadth.SinaClient", FakeSina)

    result = get_market_breadth(
        "2026-06-17",
        eastmoney=FailingEastmoney([]),
        stock_data_func=lambda *args: _bars(args[0], []),
    )

    assert result.raw["sources"]["indices"] == "sina"
    assert result.raw["sources"]["limit_stats"] == "sina"


def test_partial_result_skips_board_ladders_when_rows_fail(monkeypatch) -> None:
    class FakeTencent:
        def index_snapshots(self) -> dict[str, dict]:
            return {}

    class FakeSina:
        def index_snapshots(self) -> dict[str, dict]:
            return {}

        def market_all(self) -> list[dict]:
            raise DataSourceError("sina down")

    monkeypatch.setattr("astock_data.services.market_breadth.TencentClient", FakeTencent)
    monkeypatch.setattr("astock_data.services.market_breadth.SinaClient", FakeSina)

    result = get_market_breadth(
        "2026-06-17",
        eastmoney=FakeEastmoney([]),
        stock_data_func=lambda *args: _bars(args[0], []),
    )

    assert result.raw["sources"]["indices"] == "eastmoney"
    assert result.raw["sources"]["limit_stats"] is None
    assert result.raw["sources"]["board_ladders"] is None
    assert result.board_ladders == {}
    assert result.limit_stats.limit_up_count == 0
    assert any("board_ladders skipped" in warning for warning in result.warnings)


def test_all_sources_failure_raises_typed_error(monkeypatch) -> None:
    class FakeTencent:
        def index_snapshots(self) -> dict[str, dict]:
            raise DataSourceError("tencent down")

    class FakeSina:
        def index_snapshots(self) -> dict[str, dict]:
            raise DataSourceError("sina indices down")

        def market_all(self) -> list[dict]:
            raise DataSourceError("sina rows down")

    monkeypatch.setattr("astock_data.services.market_breadth.TencentClient", FakeTencent)
    monkeypatch.setattr("astock_data.services.market_breadth.SinaClient", FakeSina)

    with pytest.raises(DataSourceError, match="All market breadth index and full-market quote sources failed"):
        get_market_breadth("2026-06-17", eastmoney=FailingEastmoney([]))


def test_board_ladder_derives_three_boards_and_breaks_chain(monkeypatch) -> None:
    _stub_empty_tencent_sina(monkeypatch)
    rows = [{"f12": "688017", "f14": "绿的谐波", "f2": 13.31, "f3": 20.0}]
    eastmoney = FakeEastmoney(rows)

    def stock_data_func(symbol: str, start: str, end: str) -> StockDataResult:
        assert symbol == "688017"
        assert end == "2026-06-17"
        return _bars(symbol, [10.0, 12.0, 14.4, 17.28], start="2026-06-14")

    result = get_market_breadth("2026-06-17", eastmoney=eastmoney, stock_data_func=stock_data_func)

    assert 3 in result.board_ladders
    assert result.board_ladders[3][0].code == "688017"
    assert result.board_ladders[3][0].boards == 3
    assert any("derived" in warning for warning in result.warnings)


@pytest.mark.parametrize("code", ["920267", "430047"])
def test_board_ladder_derives_beijing_exchange_codes(code: str, monkeypatch) -> None:
    _stub_empty_tencent_sina(monkeypatch)
    rows = [{"f12": code, "f14": "北证样本", "f2": 16.9, "f3": 30.0}]
    requested: list[str] = []

    def stock_data_func(symbol: str, start: str, end: str) -> StockDataResult:
        requested.append(symbol)
        return StockDataResult(
            source="mock",
            retrieved_at=dt.datetime(2026, 6, 17, tzinfo=dt.UTC),
            ticker=Ticker(code=symbol, market="bj"),
            bars=[
                OHLCVBar(
                    date="2026-06-16",
                    open=13.0,
                    high=13.0,
                    low=13.0,
                    close=13.0,
                    volume=1000,
                ),
                OHLCVBar(
                    date="2026-06-17",
                    open=16.9,
                    high=16.9,
                    low=16.9,
                    close=16.9,
                    volume=1000,
                )
            ],
        )

    result = get_market_breadth(
        "2026-06-17",
        eastmoney=FakeEastmoney(rows),
        stock_data_func=stock_data_func,
    )

    assert requested == [code]
    assert result.board_ladders[1][0].code == code


def test_non_limit_day_breaks_board_chain(monkeypatch) -> None:
    _stub_empty_tencent_sina(monkeypatch)
    rows = [{"f12": "688017", "f14": "绿的谐波", "f2": 14.52, "f3": 20.0}]
    eastmoney = FakeEastmoney(rows)

    def stock_data_func(symbol: str, start: str, end: str) -> StockDataResult:
        return _bars(symbol, [10.0, 12.0, 12.1, 14.52], start="2026-06-14")

    result = get_market_breadth("2026-06-17", eastmoney=eastmoney, stock_data_func=stock_data_func)

    assert list(result.board_ladders) == [1]
    assert result.board_ladders[1][0].code == "688017"


def test_invalid_date_rejected() -> None:
    with pytest.raises(MarketValidationError):
        get_market_breadth("2026/06/17", eastmoney=FakeEastmoney([]))


def test_no_persistent_state_file_created(tmp_path, monkeypatch) -> None:
    monkeypatch.chdir(tmp_path)
    _stub_empty_tencent_sina(monkeypatch)
    result = get_market_breadth(
        "2026-06-17",
        eastmoney=FakeEastmoney([{"f12": "000001", "f14": "平安银行", "f2": 10.0, "f3": 0.0}]),
        stock_data_func=lambda *args: _bars(args[0], []),
    )

    assert result.board_ladders == {}
    assert not list(tmp_path.glob("*.sqlite"))


def test_limit_down_rows_collects_individual_limit_down_stocks(monkeypatch) -> None:
    def unavailable_hot_stocks(curr_date: str = "") -> None:
        raise DataSourceError("hot stocks unavailable")

    monkeypatch.setattr(
        "astock_data.services.signals_a.get_hot_stocks", unavailable_hot_stocks
    )
    eastmoney = FakeEastmoney(
        [
            {"f12": "000001", "f14": "平安银行", "f2": 10.98, "f3": 9.8},
            {"f12": "688017", "f14": "绿的谐波", "f2": 8.0, "f3": -19.5},
            {"f12": "600001", "f14": "*ST样本", "f2": 4.8, "f3": -4.8},
        ]
    )

    result = get_market_breadth(
        "2026-06-17",
        eastmoney=eastmoney,
        tencent=EmptyTencent(),
        sina=EmptySina(),
        stock_data_func=lambda *args: _bars(args[0], [10, 11, 12.1]),
    )

    codes = [item.code for item in result.limit_down_rows]
    assert "688017" in codes
    assert "600001" in codes
    assert result.limit_stats.limit_down_count == len(result.limit_down_rows)
    item = next(item for item in result.limit_down_rows if item.code == "688017")
    assert item.name == "绿的谐波"
    assert item.change_pct == -19.5


def test_board_item_reason_enriched_from_hot_stocks(monkeypatch) -> None:
    from astock_data.models import HotStockItem, HotStocksResult

    rows = [{"f12": "688017", "f14": "绿的谐波", "f2": 14.52, "f3": 20.0}]
    eastmoney = FakeEastmoney(rows)

    def fake_hot_stocks(curr_date: str = "") -> HotStocksResult:
        return HotStocksResult(
            source="test",
            retrieved_at=dt.datetime(2026, 6, 17, tzinfo=dt.UTC),
            date=dt.date(2026, 6, 17),
            items=[HotStockItem(code="688017", name="绿的谐波", reason="算力+国企改革")],
            theme_frequency={"算力": 1, "国企改革": 1},
        )

    monkeypatch.setattr("astock_data.services.signals_a.get_hot_stocks", fake_hot_stocks)

    result = get_market_breadth(
        "2026-06-17",
        eastmoney=eastmoney,
        tencent=EmptyTencent(),
        sina=EmptySina(),
        stock_data_func=lambda *args: _bars(
            args[0], [10.0, 12.0, 12.1, 14.52], start="2026-06-14"
        ),
    )

    all_items = [item for items in result.board_ladders.values() for item in items]
    target = next(item for item in all_items if item.code == "688017")
    assert target.reason == "算力+国企改革"


def test_hot_stocks_failure_degrades_gracefully(monkeypatch) -> None:
    def raising_hot_stocks(curr_date: str = "") -> None:
        raise RuntimeError("ths hot stocks unavailable")

    monkeypatch.setattr("astock_data.services.signals_a.get_hot_stocks", raising_hot_stocks)
    eastmoney = FakeEastmoney(
        [{"f12": "688017", "f14": "绿的谐波", "f2": 14.52, "f3": 20.0}]
    )

    result = get_market_breadth(
        "2026-06-17",
        eastmoney=eastmoney,
        stock_data_func=lambda *args: _bars(args[0], [10.0, 12.0, 14.4]),
    )

    assert any("hot_stocks reason enrichment skipped" in warning for warning in result.warnings)
    all_items = [item for items in result.board_ladders.values() for item in items]
    assert all(item.reason is None for item in all_items)
