"""Offline unit tests for SinaClient (K-line, financials, news).

All HTTP is intercepted; no live network. Marked ``unit``.
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest
import requests

from astock_data.clients.sina import SinaClient, _shsz_prefix
from astock_data.errors import DataSourceError, RateLimitError

FIXTURES = Path(__file__).parent / "fixtures"

pytestmark = pytest.mark.unit


@pytest.mark.parametrize(
    ("code", "expected"),
    [
        ("688017", "sh"),
        ("900001", "sh"),
        ("000001", "sz"),
        ("920267", "bj"),
        ("430047", "bj"),
        ("835185", "bj"),
    ],
)
def test_market_prefix_mapping(code: str, expected: str) -> None:
    assert _shsz_prefix(code) == expected


def _kline_payload() -> str:
    return (FIXTURES / "sina_kline.json").read_text(encoding="utf-8")


def _financial_payload(report_type: str) -> str:
    name = {
        "balance": "sina_financial_balance.json",
        "income": "sina_financial_income.json",
        "cashflow": "sina_financial_cashflow.json",
    }[report_type]
    return (FIXTURES / name).read_text(encoding="utf-8")


def _news_bytes() -> bytes:
    return (FIXTURES / "sina_news.html").read_bytes()


# ---------------------------------------------------------------------------
# kline
# ---------------------------------------------------------------------------


def test_kline_parses_ordered_ohlcv(requests_mocker) -> None:
    requests_mocker.get(SinaClient.KLINE_URL, text=_kline_payload())

    client = SinaClient()
    rows = client.kline("688017")

    assert len(rows) == 3
    # Ascending date order preserved.
    assert [r["date"] for r in rows] == [
        "2026-06-15", "2026-06-16", "2026-06-17",
    ]
    first = rows[0]
    assert set(first.keys()) == {"date", "open", "high", "low", "close", "volume"}
    assert first["open"] == pytest.approx(10.00)
    assert first["high"] == pytest.approx(10.10)
    assert first["low"] == pytest.approx(9.90)
    assert first["close"] == pytest.approx(10.05)
    assert first["volume"] == 1000


def test_kline_date_filter(requests_mocker) -> None:
    requests_mocker.get(SinaClient.KLINE_URL, text=_kline_payload())

    client = SinaClient()
    rows = client.kline("688017", start_date="2026-06-16", end_date="2026-06-16")
    assert len(rows) == 1
    assert rows[0]["date"] == "2026-06-16"


@pytest.mark.parametrize(
    "period,scale",
    [
        ("5min", "5"),
        ("15min", "15"),
        ("30min", "30"),
        ("60min", "60"),
        ("day", "240"),
        ("week", "1680"),
        ("month", "7200"),
    ],
)
def test_kline_period_maps_to_scale(requests_mocker, period, scale) -> None:
    captured = {}

    def _matcher(request, context):
        captured["qs"] = request.qs
        return _kline_payload()

    requests_mocker.get(SinaClient.KLINE_URL, json=_matcher)
    SinaClient().kline("688017", period=period)

    assert captured["qs"]["scale"] == [scale]


def test_kline_invalid_period_raises_value_error() -> None:
    with pytest.raises(ValueError, match="Unsupported Sina K-line period"):
        SinaClient().kline("688017", period="1min")


def test_kline_http_error_raises(requests_mocker) -> None:
    requests_mocker.get(
        SinaClient.KLINE_URL, exc=requests.ConnectionError("boom")
    )
    with pytest.raises(DataSourceError):
        SinaClient().kline("688017")


def test_kline_json_error_raises(requests_mocker) -> None:
    requests_mocker.get(SinaClient.KLINE_URL, text="not json")
    with pytest.raises(DataSourceError):
        SinaClient().kline("688017")


def test_kline_request_includes_finance_referer(requests_mocker) -> None:
    requests_mocker.get(SinaClient.KLINE_URL, text=_kline_payload())

    SinaClient().kline("688017")

    assert requests_mocker.request_history[-1].headers["Referer"] == (
        "https://finance.sina.com.cn/"
    )


def test_kline_retries_rate_limit_then_raises(monkeypatch) -> None:
    class RateLimitedSession:
        def __init__(self) -> None:
            self.calls = 0

        def get(self, url, **kwargs):
            self.calls += 1
            response = requests.Response()
            response.status_code = 429
            response.url = url
            response.headers["Retry-After"] = "0"
            return response

    monkeypatch.setattr("astock_data.clients._http.time.sleep", lambda _: None)
    session = RateLimitedSession()

    with pytest.raises(RateLimitError):
        SinaClient(session=session).kline("688017")

    assert session.calls == 3


def test_index_snapshots_parse_short_quote_payload(requests_mocker) -> None:
    payload = (
        'var hq_str_s_sh000001="上证指数,3000.00,10.00,0.33,100,1000";'
        'var hq_str_s_sz399001="深证成指,10000.00,100.00,1.01,100,1000";'
        'var hq_str_s_sz399006="创业板指,2000.00,20.00,1.01,100,1000";'
        'var hq_str_s_sh000688="科创50,900.00,-10.00,-1.10,100,1000";'
        'var hq_str_s_sh000300="沪深300,4000.00,20.00,0.50,100,1000";'
        'var hq_str_s_sh000905="中证500,6000.00,-10.00,-0.17,100,1000";'
    )
    requests_mocker.get(
        "https://hq.sinajs.cn/list=s_sh000001,s_sz399001,s_sz399006,s_sh000688,s_sh000300,s_sh000905",
        content=payload.encode("gbk"),
    )

    result = SinaClient().index_snapshots()

    assert list(result) == ["sh", "sz", "cyb", "kc50", "hs300", "zz500"]
    assert result["sh"] == {
        "name": "上证指数",
        "price": 3000.0,
        "change": 10.0,
        "change_pct": 0.33,
    }


def test_index_snapshots_http_error_raises(requests_mocker) -> None:
    requests_mocker.get(
        "https://hq.sinajs.cn/list=s_sh000001,s_sz399001,s_sz399006,s_sh000688,s_sh000300,s_sh000905",
        exc=requests.ConnectionError("boom"),
    )

    with pytest.raises(DataSourceError):
        SinaClient().index_snapshots()


def test_market_page_normalizes_rows(requests_mocker) -> None:
    captured = {}

    def _matcher(request, context):
        captured["qs"] = request.qs
        return json.dumps(
            [
                {"symbol": "sh600000", "name": "浦发银行", "trade": "10.1", "changepercent": "9.9"},
                {"code": "sz300001", "name": "特锐德", "price": "12.0", "change_pct": "20.0"},
            ],
            ensure_ascii=False,
        )

    requests_mocker.get(SinaClient.MARKET_CENTER_URL, text=_matcher)

    rows = SinaClient().market_page(page=2, page_size=2)

    assert captured["qs"]["page"] == ["2"]
    assert captured["qs"]["num"] == ["2"]
    assert rows == [
        {"code": "600000", "name": "浦发银行", "close": 10.1, "change_pct": 9.9},
        {"code": "300001", "name": "特锐德", "close": 12.0, "change_pct": 20.0},
    ]


# ---------------------------------------------------------------------------
# financial_report
# ---------------------------------------------------------------------------


@pytest.mark.parametrize("report_type,source", [
    ("balance", "fzb"),
    ("income", "lrb"),
    ("cashflow", "llb"),
])
def test_financial_report_parses_rows(requests_mocker, report_type, source) -> None:
    requests_mocker.get(
        SinaClient.FINANCE_URL, text=_financial_payload(report_type)
    )

    client = SinaClient()
    rows = client.financial_report("688017", report_type)

    assert len(rows) == 2
    # Each row has report_date + raw Chinese fields dict.
    assert "report_date" in rows[0]
    assert "fields" in rows[0]
    assert rows[0]["report_date"] == "2025-12-31"
    assert isinstance(rows[0]["fields"], dict)
    # Raw Chinese field names preserved verbatim.
    assert "报告日" in rows[0]["fields"]


def test_financial_report_unknown_type_raises(requests_mocker) -> None:
    with pytest.raises(DataSourceError):
        SinaClient().financial_report("688017", "bogus")


def test_financial_report_http_error_raises(requests_mocker) -> None:
    requests_mocker.get(
        SinaClient.FINANCE_URL, exc=requests.ConnectionError("boom")
    )
    with pytest.raises(DataSourceError):
        SinaClient().financial_report("688017", "balance")


def test_financial_report_url_params(requests_mocker) -> None:
    captured = {}

    def _matcher(request, context):
        captured["qs"] = request.qs
        return _financial_payload("income")

    requests_mocker.get(SinaClient.FINANCE_URL, json=_matcher)
    SinaClient().financial_report("688017", "income")
    # paperCode must carry the sh prefix for a 6-leading code.
    assert captured["qs"]["papercode"] == ["sh688017"]
    assert captured["qs"]["source"] == ["lrb"]


# ---------------------------------------------------------------------------
# news
# ---------------------------------------------------------------------------


def test_news_parses_items(requests_mocker) -> None:
    requests_mocker.get(SinaClient.NEWS_URL, content=_news_bytes())

    client = SinaClient()
    items = client.news("688017")

    assert len(items) == 2
    item = items[0]
    assert set(item.keys()) == {"title", "content", "time", "source", "url"}
    assert item["source"] == "新浪财经"
    assert item["content"] == ""
    assert item["url"].startswith("https://finance.sina.com.cn/")
    assert item["time"] == "2026-06-17 10:30"
    # Title is GBK-decoded Chinese (non-empty).
    assert item["title"]


def test_news_page_size_limit(requests_mocker) -> None:
    requests_mocker.get(SinaClient.NEWS_URL, content=_news_bytes())
    items = SinaClient().news("688017", page_size=1)
    assert len(items) == 1


def test_news_http_error_raises(requests_mocker) -> None:
    requests_mocker.get(
        SinaClient.NEWS_URL, exc=requests.ConnectionError("boom")
    )
    with pytest.raises(DataSourceError):
        SinaClient().news("688017")


def test_injected_session_is_used(requests_mocker) -> None:
    session = requests.Session()
    requests_mocker.get(SinaClient.KLINE_URL, text=_kline_payload())
    client = SinaClient(session=session)
    assert client.session is session
    assert client.kline("688017")
